#!/bin/bash

echo "*manually* added"
echo "# 27,Nop"
echo "to start of each pointer function"
echo "# 27,Nop"
echo "to start of each spiker function"
