Enumerated value classes.
