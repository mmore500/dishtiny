#!/bin/bash

make production
