#!/bin/bash

echo "*manually* added"
echo "# 121,TryAddFledglingConnection"
echo "to start of each pointer function"
echo "# 98,TryAddFledglingConnection"
echo "to start of each spiker function"
